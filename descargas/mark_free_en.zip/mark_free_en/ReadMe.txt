﻿
============================================================

Sample Model
Mark (FREE version)

============================================================

It is a model to learn simple structure.

You can learn the simple structure of  the deformers and the parameters.
Physics Settings and Eye-Blink features are supported. 
You can also learn how to use it in the SDK.


------------------------------
License Agreement
------------------------------

  You need to agree "Free Material License Agreement" to use this sample model.　

  General Users and Small-Scale Enterprise Users can use the model for 
  commercial purpose by accepting the "Free Material License Agreement".
  Parties other than General User or Small-Scale Enterprise User is 
  allowed to use the model for Internal or Supervision Purpose.
　Please refer to this agreement for more details.
　Free Material License Agreement
　http://www.live2d.com/eula/live2d-free-material-license-agreement_en.html


------------------------------
Created By
------------------------------

　Illustration：Live2D
　Modeling：Live2D


------------------------------
Sample Data Composition
------------------------------

  Model Data(cmo3) Note:Including physics settings
  Motion(can3)
  Background(png)


------------------------------
Release Note
------------------------------

　【cmo3】

　mark_free_t02
　2019/02/20　Confirm the target saving version for Cubism3.3.00
　mark_free_t01
　2017/09/22　released



　【can3】

　mark_free_t02
　2017/12/12　Add playlist

　mark_free_t01
　2017/09/22　released